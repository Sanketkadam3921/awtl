document
  .getElementById("patientForm")
  .addEventListener("submit", function (event) {
    // Basic validation
    const phonePattern = /^[0-9]{10}$/;
    const phone = document.getElementById("phone").value;

    if (!phonePattern.test(phone)) {
      alert("Please enter a valid 10-digit phone number.");
      event.preventDefault(); // Prevent form submission
    }

    // Additional validation can be added here
  });
