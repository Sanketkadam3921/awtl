angular.module("groceryApp", []).controller("FormController", function () {
  var vm = this;
  vm.item = {};

  vm.submitForm = function (isValid) {
    if (isValid) {
      alert("Form is valid!");
    } else {
      alert("Please fill out the form correctly.");
    }
  };
});
