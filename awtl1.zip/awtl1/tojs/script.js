document.addEventListener("DOMContentLoaded", () => {
  const todoForm = document.getElementById("todoForm");
  const todoInput = document.getElementById("todoInput");
  const todoList = document.getElementById("todoList");

  todoForm.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form submission

    const taskText = todoInput.value.trim();
    if (taskText === "") return;

    const todoItem = document.createElement("li");
    todoItem.classList.add("todo-item");
    todoItem.innerHTML = `
            <span>${taskText}</span>
            <button class="delete-btn">Delete</button>
        `;

    todoList.appendChild(todoItem);
    todoInput.value = ""; // Clear the input field

    const deleteButton = todoItem.querySelector(".delete-btn");
    deleteButton.addEventListener("click", () => {
      todoList.removeChild(todoItem);
    });
  });
});
