var app = angular.module("complaintApp", []);

app.controller("ComplaintController", [
  "$scope",
  function ($scope) {
    $scope.complaint = {};

    $scope.submitForm = function (isValid) {
      if (isValid) {
        alert("Complaint submitted successfully!");
      }
    };
  },
]);
