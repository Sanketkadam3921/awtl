// Import required modules
const http = require("http");
const os = require("os");
const path = require("path");
const EventEmitter = require("events");

// Create an EventEmitter instance
const eventEmitter = new EventEmitter();

// Define event handler for 'customEvent' event
eventEmitter.on("customEvent", (message) => {
  console.log("Custom Event:", message);
});

// Create a custom server using the http module
const server = http.createServer((req, res) => {
  if (req.url === "/") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.write("<h1>Hello World!</h1>");
    res.end();
  } else if (req.url === "/about") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.write("<h1>About Us</h1>");
    res.end();
  } else if (req.url === "/contact") {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.write("<h1>Contact Us</h1>");
    res.end();
  } else {
    res.writeHead(404, { "Content-Type": "text/html" });
    res.write("<h1>404 Not Found</h1>");
    res.end();
  }
});

// Start the server listening on port 3000
server.listen(3000, () => {
  console.log("Server running at http://localhost:3000/");
});

// Print system information using the os module
console.log("Operating system:", os.platform());
console.log("CPU architecture:", os.arch());
console.log("Total memory:", os.totalmem() / (1024 * 1024) + " MB");

// Print file path information using the path module
console.log("Current directory:", __dirname);
console.log("File name:", path.basename(__filename));
console.log("File extension:", path.extname(__filename));

// Emit custom event
eventEmitter.emit("customEvent", "This is a custom event!");
