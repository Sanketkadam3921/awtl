var app = angular.module("cakeShopApp", []);

app.controller("OrderController", [
  "$scope",
  function ($scope) {
    $scope.order = {};

    $scope.submitOrder = function (isValid) {
      if (isValid) {
        alert("Order submitted successfully!");
      }
    };
  },
]);
