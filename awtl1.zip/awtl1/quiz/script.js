document
  .getElementById("quizForm")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form submission

    const correctAnswers = {
      q1: "c",
      q2: "c",
      q3: "a",
    };

    let score = 0;
    const formData = new FormData(event.target);

    for (let [question, answer] of formData.entries()) {
      if (correctAnswers[question] === answer) {
        score++;
      }
    }

    const resultDiv = document.getElementById("result");
    resultDiv.textContent = `You got ${score} out of ${
      Object.keys(correctAnswers).length
    } correct.`;
  });
